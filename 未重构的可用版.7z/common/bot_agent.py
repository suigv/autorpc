# 文件名: bot_agent.py
# -*- coding: utf-8 -*-
import time
import random
import functools
from common.mytRpc import MytRpc
from common.logger import logger
from common.ToolsKit import ToolsKit
from common.x_config import XConfig


# ================= 🛡️ 安全装饰器 (核心增强) =================
def safe_action(retries=3, delay=1.0):
    """
    自动重试与异常捕获装饰器。
    有了它，你不需要在每个方法里写 try-except，也不怕 RPC 突然断开。
    """

    def decorator(func):
        @functools.wraps(func)
        def wrapper(self, *args, **kwargs):
            last_err = None
            for i in range(retries):
                try:
                    if not self._is_connected:
                        # 如果掉线尝试重连
                        self.log(f"检测到连接断开，尝试重连 ({i + 1})...")
                        if not self.connect():
                            time.sleep(2)
                            continue

                    return func(self, *args, **kwargs)
                except Exception as e:
                    last_err = e
                    self.log(f"⚠️ 操作 {func.__name__} 失败 (第 {i + 1} 次): {e}")
                    time.sleep(delay)

            self.log(f"❌ 操作 {func.__name__} 彻底失败: {last_err}")
            return False  # 统一返回 False 表示失败

        return wrapper

    return decorator


class BotAgent:
    """
    [Final Version]
    提供全套原子操作，内置重试机制，真正实现业务逻辑解耦。
    """

    @staticmethod
    def calculate_ports(index):
        """
        统一的端口计算逻辑
        :param index: 设备序号 (1-based)
        :return: (rpa_port, api_port)
        """
        base_port = 30000 + (index - 1) * 100
        rpa_port = base_port + 2
        api_port = base_port + 1
        return rpa_port, api_port

    def __init__(self, index, host_ip, log_func=None):
        self.index = index
        self.host_ip = host_ip
        self.log_callback = log_func
        self.cfg = XConfig

        # 使用统一的端口计算
        self.rpa_port, _ = self.calculate_ports(index)

        self.rpa = MytRpc()
        self.tools = ToolsKit()
        self._is_connected = False

    # ================= 1. 连接管理 =================

    def __enter__(self):
        if self.connect():
            return self
        raise ConnectionError(f"[Device {self.index}] RPA连接失败")

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.quit()

    def connect(self):
        try:
            if self.rpa.init(self.host_ip, self.rpa_port, 10):
                self._is_connected = True
                return True
        except Exception as e:
            logger.error(f"连接异常: {e}")
        return False

    def quit(self):
        self._is_connected = False
        # 可以在这里显式调用 rpa 的清理，如果 SDK 支持

    def log(self, message):
        full_msg = f"[Dev {self.index}] {message}"
        if self.log_callback:
            self.log_callback(full_msg)
        logger.info(full_msg)

    # ================= 2. 基础原子操作 (加固版) =================

    @safe_action(retries=2)
    def shell_cmd(self, cmd):
        """执行 ADB Shell 命令"""
        return self.rpa.exec_cmd(cmd)

    @safe_action(retries=3)
    def exists_text(self, text, timeout=500):
        """检查文本是否存在 (匹配 text 属性)"""
        selector = self.rpa.create_selector()
        if not selector: return False
        with selector:
            selector.addQuery_TextContainWith(text)
            node = selector.execQueryOne(timeout)
            return node is not None

    @safe_action(retries=3)
    def exists_desc(self, text, timeout=500):
        """检查描述是否存在 (匹配 content-desc 属性)"""
        selector = self.rpa.create_selector()
        if not selector: return False
        with selector:
            selector.addQuery_DescContainWith(text)
            node = selector.execQueryOne(timeout)
            return node is not None

    @safe_action(retries=3)
    def is_tab_selected(self, keyword, timeout=1000):
        """
        检查底部导航栏的 Tab 是否被选中
        原理：查找 content-desc 包含 keyword 且 selected=true 的节点
        """
        selector = self.rpa.create_selector()
        if not selector: return False
        with selector:
            selector.addQuery_DescContainWith(keyword)
            selector.addQuery_Selectedable(True) # 筛选 selected=true
            node = selector.execQueryOne(timeout)
            return node is not None

    @safe_action(retries=3)
    def click_text(self, text, timeout=2000):
        """点击文本 (增强版：支持点击不可点文本的父容器)"""
        selector = self.rpa.create_selector()
        if not selector: return False
        with selector:
            selector.addQuery_TextContainWith(text)
            # 1. 优先找可点击的
            selector.addQuery_Clickable(True)
            node = selector.execQueryOne(timeout)
            
            if not node:
                # 2. 回退：找不可点的，然后点击
                # RPA 的 Click_events 通常是点击节点中心坐标，所以即使节点本身不可点，
                # 只要它在可点击的父容器内，点击其坐标通常也能触发父容器的点击事件。
                selector.clear_Query()
                selector.addQuery_TextContainWith(text)
                node = selector.execQueryOne(timeout)

            if node:
                node.Click_events()
                self.log(f"🖱️ 点击 -> [{text}]")
                return True
        return False

    @safe_action(retries=3)
    def click_id(self, res_id, timeout=2000):
        """点击资源ID (应对没有文字的图标按钮)"""
        selector = self.rpa.create_selector()
        if not selector: return False
        with selector:
            selector.addQuery_IdEqual(res_id)
            selector.addQuery_Clickable(True)
            node = selector.execQueryOne(timeout)
            if node:
                node.Click_events()
                self.log(f"🖱️ 点击ID -> [{res_id}]")
                return True
        return False
    
    @safe_action(retries=3)
    def click_desc(self, desc, timeout=2000):
        """点击 Content-Desc"""
        selector = self.rpa.create_selector()
        if not selector: return False
        with selector:
            selector.addQuery_DescContainWith(desc)
            selector.addQuery_Clickable(True)
            node = selector.execQueryOne(timeout)
            
            if not node:
                selector.clear_Query()
                selector.addQuery_DescContainWith(desc)
                node = selector.execQueryOne(timeout)

            if node:
                node.Click_events()
                self.log(f"🖱️ 点击Desc -> [{desc}]")
                return True
        return False

    @safe_action(retries=2)
    def input_text(self, text, hint_text=None):
        """输入文本"""
        if hint_text:
            if not self.click_text(hint_text):
                return False
            time.sleep(0.5)

        self.rpa.sendText(text)
        self.log(f"⌨️ 输入 -> {text[:5]}...")
        return True
    
    @safe_action(retries=2)
    def keyPress(self, key_code):
        """发送物理按键"""
        return self.rpa.keyPress(key_code)

    @safe_action(retries=2)
    def swipe_screen(self, direction="up", distance=0.5):
        """防封滑动"""
        w, h = 1080, 1920
        center_x, center_y = w // 2, h // 2
        offset = int(h * distance / 2)

        sx, sy, ex, ey = center_x, center_y, center_x, center_y

        if direction == "up":
            sy, ey = center_y + offset, center_y - offset
        elif direction == "down":
            sy, ey = center_y - offset, center_y + offset

        jitter = random.randint(-20, 20)
        sx += jitter
        ex -= jitter

        cmd = f"input swipe {sx} {sy} {ex} {ey} {random.randint(180, 250)}"
        self.shell_cmd(cmd)
        return True

    # ================= 3. 高级功能 (Scheme & App) =================

    @safe_action(retries=1)
    def jump_to(self, uri):
        """Scheme 跳转"""
        self.log(f"🔗 跳转: {uri[:40]}...")
        cmd = f"am start -a android.intent.action.VIEW -d \"{uri}\" &"
        self.shell_cmd(cmd)
        time.sleep(3)
        return True

    def launch_app(self):
        """启动 App"""
        pkg = self.cfg.PACKAGE_NAME
        try:
            if hasattr(self.rpa, 'openApp') and self.rpa.openApp(pkg):
                self.log("[SDK] 启动指令发送")
        except:
            pass

        time.sleep(1)
        self.shell_cmd(f"am start -n {pkg}/{self.cfg.ACTIVITY_NAME}")
        return self._wait_for_launch_complete()

    def _wait_for_launch_complete(self, timeout=15):
        start = time.time()
        home_keywords = [
            self.cfg.UI_TEXT.get("HOME_TAB", "ホーム"),
            "Home"
        ]

        while time.time() - start < timeout:
            if self.is_on_home_page(home_keywords):
                self.log("✅ App 就绪 (主页)")
                return True
            time.sleep(1)
        return False

    def is_on_page(self, keywords, timeout=500):
        """通用页面检测 (文本或描述存在即可)"""
        if isinstance(keywords, str): keywords = [keywords]
        for kw in keywords:
            if not kw: continue
            if self.exists_text(kw, timeout=timeout):
                return True
            if self.exists_desc(kw, timeout=timeout):
                return True
        return False

    def is_on_home_page(self, keywords=None, timeout=1000):
        """
        精准判断是否在主页
        检查底部导航栏的 Home 图标是否处于 Selected 状态
        """
        if not keywords:
            keywords = [self.cfg.UI_TEXT.get("HOME_TAB", "ホーム"), "Home"]
        
        if isinstance(keywords, str): keywords = [keywords]
        
        for kw in keywords:
            if self.is_tab_selected(kw, timeout):
                return True
        return False

    # ================= 4. 环境与预留接口 =================

    def grant_all_permissions(self):
        """
        [新增] 预先授予所有必要权限 (通知、相册、存储)
        """
        pkg = self.cfg.PACKAGE_NAME
        self.log("🛡️ 正在预授权应用权限...")
        
        perms = [
            "android.permission.POST_NOTIFICATIONS",
            "android.permission.READ_MEDIA_IMAGES",
            "android.permission.READ_MEDIA_VIDEO",
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE",
            "android.permission.CAMERA"
        ]
        
        for p in perms:
            self.shell_cmd(f"pm grant {pkg} {p}")
            
        self.log("✅ 权限授予指令已发送")
        return True

    def check_env(self):
        tz = self.shell_cmd("getprop persist.sys.timezone")
        if "Tokyo" not in str(tz) and "Japan" not in str(tz):
            self.log(f"⚠️ 时区异常: {tz}")
            return False
        return True

    def dismiss_popups(self):
        popups = [self.cfg.UI_TEXT.get("POPUP_NOT_NOW"), self.cfg.UI_TEXT.get("POPUP_DENY")]
        for p in popups:
            if p and self.click_text(p, timeout=300):
                self.log(f"🛡️ 关闭弹窗: {p}")
                return True
        return False

    def get_screen_text(self):
        return ""