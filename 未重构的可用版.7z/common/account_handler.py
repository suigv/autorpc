# -*- coding: utf-8 -*-
import os
import threading
from common.ToolsKit import ToolsKit

class AccountHandler:
    _lock = threading.Lock()
    ACCOUNT_FILE = "账号.txt"
    LOG_DIR = "log"

    @staticmethod
    def _ensure_log_dir():
        tools = ToolsKit()
        root = tools.GetRootPath()
        log_path = os.path.join(root, AccountHandler.LOG_DIR)
        if not os.path.exists(log_path):
            os.makedirs(log_path)
        return log_path

    @staticmethod
    def get_finish_file(device_index):
        log_dir = AccountHandler._ensure_log_dir()
        return os.path.join(log_dir, f"Finish{device_index}.txt")

    @staticmethod
    def get_account(device_index):
        """
        适配 task_login.py 的接口
        Returns: (user, pwd, fa2)
        """
        data, _ = AccountHandler.get_valid_account(device_index)
        if data:
            return data.get("user"), data.get("pass"), data.get("2fa")
        return None

    @staticmethod
    def get_valid_account(device_index):
        """
        获取一个可用账号：
        1. 优先检查 Finish{i}.txt 的最后一行（掉线重登）。
        2. 如果不可用（文件不存在、为空、或标记为 INVALID），则从 账号.txt 取新号。
        
        Returns:
            dict: 账号数据字典
            bool: is_new_account (是否是新取的号)
        """
        finish_file = AccountHandler.get_finish_file(device_index)
        
        # --- 1. 尝试获取旧号 ---
        last_line = None
        if os.path.exists(finish_file):
            with open(finish_file, "r", encoding="utf-8") as f:
                lines = f.readlines()
                # 倒序查找最后一条非空记录
                for line in reversed(lines):
                    if line.strip():
                        last_line = line.strip()
                        break
        
        if last_line:
            # 检查是否标记为废号
            if "----INVALID" in last_line:
                print(f"[Dev {device_index}] 上次账号已标记为废号，尝试取新号...")
            else:
                print(f"[Dev {device_index}] 检测到历史账号，尝试重登...")
                return AccountHandler._parse_account(last_line), False

        # --- 2. 取新号 ---
        return AccountHandler._fetch_new_account(device_index), True

    @staticmethod
    def _fetch_new_account(device_index):
        """从主文件取号并转移到 Finish 文件"""
        tools = ToolsKit()
        root = tools.GetRootPath()
        acc_path = os.path.join(root, AccountHandler.ACCOUNT_FILE)
        
        with AccountHandler._lock:
            if not os.path.exists(acc_path):
                print(f"[Dev {device_index}] ❌ 账号文件不存在: {acc_path}")
                return None

            with open(acc_path, "r", encoding="utf-8") as f:
                lines = f.readlines()
            
            valid_lines = [line for line in lines if line.strip()]
            if not valid_lines:
                print(f"[Dev {device_index}] ❌ 账号文件已空")
                return None
            
            # 取第一条
            current_line = valid_lines.pop(0).strip()
            
            # 写回主文件
            with open(acc_path, "w", encoding="utf-8") as f:
                f.writelines(valid_lines)
            
            # 写入 Finish 文件
            finish_file = AccountHandler.get_finish_file(device_index)
            with open(finish_file, "a", encoding="utf-8") as f:
                f.write(current_line + "\n")
            
            print(f"[Dev {device_index}] ✅ 已提取新账号并归档")
            return AccountHandler._parse_account(current_line)

    @staticmethod
    def mark_current_invalid(device_index):
        """将 Finish 文件中最后一行标记为 INVALID"""
        finish_file = AccountHandler.get_finish_file(device_index)
        if not os.path.exists(finish_file):
            return

        lines = []
        with open(finish_file, "r", encoding="utf-8") as f:
            lines = f.readlines()
        
        if not lines:
            return

        # 找到最后一行有效数据
        last_idx = -1
        for i in range(len(lines) - 1, -1, -1):
            if lines[i].strip():
                last_idx = i
                break
        
        if last_idx != -1:
            if "----INVALID" not in lines[last_idx]:
                lines[last_idx] = lines[last_idx].strip() + "----INVALID\n"
                with open(finish_file, "w", encoding="utf-8") as f:
                    f.writelines(lines)
                print(f"[Dev {device_index}] 🚫 账号已标记为废号")

    @staticmethod
    def _parse_account(line_str):
        if not line_str: return None
        # 去除可能存在的 INVALID 标记再解析
        clean_str = line_str.replace("----INVALID", "")
        parts = clean_str.split("----")
        
        # 兼容不同格式，假设至少有 user----pass
        if len(parts) < 2: return None
        
        return {
            "user": parts[0],
            "pass": parts[1],
            "email": parts[2] if len(parts) > 2 else "",
            "email_pass": parts[3] if len(parts) > 3 else "",
            "token": parts[4] if len(parts) > 4 else "",
            "2fa": parts[5] if len(parts) > 5 else ""
        }
