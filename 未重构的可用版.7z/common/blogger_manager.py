# common/blogger_manager.py
import os
import json
import time
import threading
from common.ToolsKit import ToolsKit

class BloggerManager:
    _lock = threading.Lock()
    
    @staticmethod
    def _get_files(ai_type):
        """
        根据 AI 类型获取对应的文件路径配置
        volc -> 交友 -> jy_前缀
        part_time -> 兼职 -> jz_前缀
        """
        prefix = "jy" if ai_type == "volc" else "jz"
        backup_file = "交友博主.txt" if ai_type == "volc" else "兼职博主.txt"
        
        return {
            "pool": f"log/{prefix}_bloggers_pool.json",
            "binding": f"log/{prefix}_device_binding.json",
            "status": f"log/{prefix}_scrape_status.json",
            "history": f"log/{prefix}_history.txt",
            "current_user": f"log/{prefix}_current_users.json",
            "backup": backup_file
        }

    @staticmethod
    def _get_path(filename):
        tools = ToolsKit()
        root = tools.GetRootPath()
        path = os.path.join(root, filename)
        
        directory = os.path.dirname(path)
        if not os.path.exists(directory):
            os.makedirs(directory)
            
        return path

    @staticmethod
    def _load_json(filename, default=None):
        path = BloggerManager._get_path(filename)
        if not os.path.exists(path):
            return default if default is not None else {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            return default if default is not None else {}

    @staticmethod
    def _save_json(filename, data):
        path = BloggerManager._get_path(filename)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    @staticmethod
    def _append_history(filename, bloggers):
        path = BloggerManager._get_path(filename)
        with open(path, "a", encoding="utf-8") as f:
            for b in bloggers:
                f.write(f"{b}\n")

    @staticmethod
    def _load_history(filename):
        path = BloggerManager._get_path(filename)
        if not os.path.exists(path): return set()
        with open(path, "r", encoding="utf-8") as f:
            return set(line.strip() for line in f if line.strip())
            
    @staticmethod
    def _remove_from_history(filename, blogger):
        path = BloggerManager._get_path(filename)
        if not os.path.exists(path): return
        try:
            with open(path, "r", encoding="utf-8") as f:
                lines = [line.strip() for line in f if line.strip()]
            if blogger in lines:
                lines.remove(blogger)
                with open(path, "w", encoding="utf-8") as f:
                    for line in lines:
                        f.write(f"{line}\n")
        except:
            pass

    @staticmethod
    def _recycle_all_history(ai_type):
        files = BloggerManager._get_files(ai_type)
        path = BloggerManager._get_path(files["history"])
        
        if not os.path.exists(path): return False
        try:
            with open(path, "r", encoding="utf-8") as f:
                lines = [line.strip() for line in f if line.strip()]
            if not lines: return False
            
            pool = BloggerManager._load_json(files["pool"], {"data": []})
            # 注意：现在 pool 结构简化为 {"data": []}，因为文件本身已经区分了类型
            
            existing = set(pool.get("data", []))
            for b in lines:
                if b not in existing:
                    pool.setdefault("data", []).append(b)
            
            BloggerManager._save_json(files["pool"], pool)
            with open(path, "w", encoding="utf-8") as f:
                f.write("")
            return True
        except:
            return False

    # --- 核心接口 ---

    @staticmethod
    def set_current_user(device_index, username, ai_type="volc"):
        # 默认 volc 是为了兼容旧代码，实际上应该传入 ai_type
        # 但 current_user 其实跟 ai_type 关系不大，它是设备属性
        # 为了简单，我们假设 current_user 存储在对应业务的文件里
        # 或者，我们可以让 current_user 不区分业务类型（因为设备登录的号是唯一的）
        # 建议：current_user 不区分前缀，统一存 log/current_users.json
        # 但为了符合您的"保持数据整洁"要求，我们还是按 ai_type 存
        files = BloggerManager._get_files(ai_type)
        with BloggerManager._lock:
            users = BloggerManager._load_json(files["current_user"])
            users[str(device_index)] = username.replace("@", "").strip()
            BloggerManager._save_json(files["current_user"], users)

    @staticmethod
    def get_current_user(device_index, ai_type="volc"):
        files = BloggerManager._get_files(ai_type)
        users = BloggerManager._load_json(files["current_user"])
        return users.get(str(device_index))

    @staticmethod
    def get_blogger(device_index, ai_type):
        """
        获取博主
        Returns: (blogger, need_scrape, is_new_binding)
        """
        dev_key = str(device_index)
        files = BloggerManager._get_files(ai_type)
        
        with BloggerManager._lock:
            # 1. 检查绑定
            bindings = BloggerManager._load_json(files["binding"])
            if dev_key in bindings:
                # 既然文件已经隔离，只要有记录就是匹配的
                return bindings[dev_key]["blogger"], False, False
            
            # 2. 检查库存
            pool = BloggerManager._load_json(files["pool"], {"data": []})
            target_pool = pool.get("data", [])
            
            if target_pool:
                blogger = target_pool.pop(0)
            else:
                # 3. 库存不足 -> 优先检查冷却
                status = BloggerManager._load_json(files["status"])
                last_scrape = status.get(dev_key, {}).get("last_scrape_time", 0)
                
                if time.time() - last_scrape > 3600: 
                    return None, True, False 
                
                # 4. 冷却中 -> 尝试从备用文件获取
                backup_blogger = BloggerManager._get_unused_backup_blogger(files)
                if backup_blogger:
                    blogger = backup_blogger
                    print(f"[Dev {device_index}] 冷却中，从{files['backup']}获取备用: {blogger}")
                else:
                    # 5. 备用也没了 -> 尝试回收历史
                    print(f"[Dev {device_index}] ⚠️ 资源耗尽且在冷却中，尝试回收历史记录...")
                    if BloggerManager._recycle_all_history(ai_type):
                        pool = BloggerManager._load_json(files["pool"])
                        target_pool = pool.get("data", [])
                        if target_pool:
                            blogger = target_pool.pop(0)
                            print(f"[Dev {device_index}] ♻️ 成功回收并分配博主: {blogger}")
                        else:
                            return None, False, False
                    else:
                        return None, False, False

            # 保存
            pool["data"] = target_pool
            BloggerManager._save_json(files["pool"], pool)
            
            bindings[dev_key] = {
                "blogger": blogger,
                "time": time.time()
            }
            BloggerManager._save_json(files["binding"], bindings)
            
            BloggerManager._append_history(files["history"], [blogger])
            
            return blogger, False, True

    @staticmethod
    def add_bloggers(ai_type, new_bloggers, device_index=None):
        files = BloggerManager._get_files(ai_type)
        
        with BloggerManager._lock:
            history = BloggerManager._load_history(files["history"])
            pool = BloggerManager._load_json(files["pool"], {"data": []})
            
            current_user = None
            if device_index:
                users = BloggerManager._load_json(files["current_user"])
                current_user = users.get(str(device_index))

            valid_bloggers = []
            for b in new_bloggers:
                b = b.replace("@", "").strip()
                if current_user and b.lower() == current_user.lower():
                    continue
                
                if b and b not in history and b not in pool.get("data", []):
                    valid_bloggers.append(b)
            
            if valid_bloggers:
                pool.setdefault("data", []).extend(valid_bloggers)
                BloggerManager._save_json(files["pool"], pool)
                return len(valid_bloggers)
            return 0

    @staticmethod
    def update_scrape_time(device_index, ai_type="volc"):
        # 注意：这里需要传入 ai_type，因为 status 文件也隔离了
        # 但调用处可能没传，为了兼容，我们可以尝试推断或者要求调用处修改
        # 暂时默认 volc，或者在 task_scrape_blogger 中修改调用
        files = BloggerManager._get_files(ai_type)
        with BloggerManager._lock:
            status = BloggerManager._load_json(files["status"])
            status[str(device_index)] = {"last_scrape_time": time.time()}
            BloggerManager._save_json(files["status"], status)

    @staticmethod
    def reset_binding_and_cooling(device_index):
        """
        重置绑定和冷却 (需要遍历所有类型的配置文件进行清理)
        """
        dev_key = str(device_index)
        # 遍历两种类型
        for ai_type in ["volc", "part_time"]:
            files = BloggerManager._get_files(ai_type)
            with BloggerManager._lock:
                # 1. 回收博主
                bindings = BloggerManager._load_json(files["binding"])
                if dev_key in bindings:
                    binding = bindings[dev_key]
                    blogger = binding.get("blogger")
                    
                    if blogger:
                        BloggerManager._remove_from_history(files["history"], blogger)
                        pool = BloggerManager._load_json(files["pool"], {"data": []})
                        pool.setdefault("data", []).insert(0, blogger)
                        BloggerManager._save_json(files["pool"], pool)
                        print(f"[Dev {device_index}] ♻️ [{ai_type}] 博主 {blogger} 已回收")

                    del bindings[dev_key]
                    BloggerManager._save_json(files["binding"], bindings)
                
                # 2. 清除冷却
                status = BloggerManager._load_json(files["status"])
                if dev_key in status:
                    del status[dev_key]
                    BloggerManager._save_json(files["status"], status)

    @staticmethod
    def _get_unused_backup_blogger(files):
        path = BloggerManager._get_path(files["backup"])
        if not os.path.exists(path): return None
        
        history = BloggerManager._load_history(files["history"])
        try:
            with open(path, "r", encoding="utf-8") as f:
                lines = [line.strip().replace("@", "") for line in f if line.strip()]
            for b in lines:
                if b not in history:
                    return b
        except:
            pass
        return None
