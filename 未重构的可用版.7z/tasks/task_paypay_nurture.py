# tasks/task_paypay_nurture.py
import time
import random
import os
from common.bot_agent import BotAgent
from common.x_config import XConfig
from common.x_scheme import XScheme
from common.ToolsKit import ToolsKit

def get_assigned_blogger(device_index, file_path="博主.txt"):
    """获取分配的博主账号 (用于替换关键词中的 {blogger})"""
    tools = ToolsKit()
    root_path = tools.GetRootPath()
    if not os.path.exists(file_path):
        file_path = os.path.join(root_path, file_path)
    
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            lines = [line.strip() for line in f if line.strip()]
        
        target_index = device_index - 1
        if target_index < len(lines):
            return lines[target_index].replace("@", "").strip()
    except:
        pass
    return "kamakiri_pay" # 默认兜底

def load_keywords():
    """加载所有关键词 (仅从 XConfig)"""
    return list(set(XConfig.PAYPAY_KEYWORDS))

def is_blacklisted(text):
    """检查文本是否包含黑名单词汇"""
    if not text: return False
    for bad_word in XConfig.PAYPAY_BLACKLIST:
        if bad_word in text:
            return True
    return False

def run_paypay_nurture_task(device_info, _unused, stop_event):
    """
    PayPay 养号任务：搜索 -> 滑动 -> 随机交互 (带黑名单过滤)
    """
    ip = device_info['ip']
    idx = device_info['index']
    bot = BotAgent(idx, ip)
    
    try:
        if not bot.connect():
            bot.log("❌ 连接失败")
            return

        bot.log("🚀 开始 PayPay 养号任务...")

        # 1. 智能启动
        if bot.is_on_home_page():
            bot.log("✅ 已在主页")
        else:
            bot.log("启动 X 应用...")
            bot.launch_app()

        if stop_event.is_set(): return

        # 2. 准备关键词 (加权随机)
        target_keywords = random.sample(load_keywords(), min(2, len(load_keywords())))
        blogger = get_assigned_blogger(idx)
        
        for kw in target_keywords:
            if stop_event.is_set(): break
            
            # 替换占位符
            final_kw = kw.replace("{blogger}", blogger)
            
            # 随机选择搜索模式 (Live vs Top)
            is_live = random.random() < 0.7
            mode_str = "最新(Live)" if is_live else "热门(Top)"
            
            bot.log(f"🔍 搜索: {final_kw} [{mode_str}]")
            
            # 3. 执行搜索
            search_uri = XScheme.get_url(XScheme.SEARCH, query=final_kw, latest=is_live)
            bot.shell_cmd(XScheme.wrap_command(search_uri))
            time.sleep(8) # 等待搜索结果加载
            
            # --- 补救措施：检查并点击标签页 ---
            # 如果目标是 Live，但没在 Live，尝试点击 "最新"
            if is_live:
                # 检查 "最新" 是否被选中 (selected=true)
                # 由于 BotAgent.is_tab_selected 是通用的，我们可以复用
                # 但这里 "最新" 不是底部导航，而是顶部 Tab，逻辑可能略有不同
                # 简单处理：如果存在 "最新" 且未选中，点击它
                # 或者直接盲点 "最新" (如果存在)
                if bot.exists_desc("最新"):
                    # 检查是否选中比较麻烦，直接点击最稳妥
                    # 如果已经选中，点击也没副作用
                    bot.log("👉 确保切换到 [最新] 标签")
                    bot.click_desc("最新")
                    time.sleep(3)
            
            # 4. 深度养成循环
            swipe_count = random.randint(8, 15)
            bot.log(f"👀 浏览 {swipe_count} 次...")
            
            already_clicked_y = []
            
            for i in range(swipe_count):
                if stop_event.is_set(): break
                
                # 查找帖子容器
                selector = bot.rpa.create_selector()
                if selector:
                    with selector:
                        selector.addQuery_IdEqual("com.twitter.android:id/row")
                        nodes = selector.execQuery(10, 2000)
                        
                        if nodes:
                            # 随机选一个帖子进行交互
                            target_node = random.choice(nodes)
                            bounds = target_node.getNodeNound()
                            desc = target_node.getNodeDesc()
                            
                            # 坐标过滤
                            if bounds['top'] < 350 or bounds['bottom'] > 1800:
                                pass # 跳过
                            elif is_blacklisted(desc):
                                bot.log("🚫 命中黑名单，跳过")
                            else:
                                # 随机行为决策
                                action_roll = random.random()
                                
                                # 30% 概率点赞 (坐标推算)
                                if action_roll < 0.3:
                                    target_x = int(1080 * 0.62)
                                    target_y = bounds['bottom'] - 60
                                    
                                    center_y = (bounds['top'] + bounds['bottom']) // 2
                                    if not any(abs(center_y - old_y) < 100 for old_y in already_clicked_y):
                                        bot.log(f"❤️ 随机点赞 (y={target_y})")
                                        bot.rpa.touchClick(0, target_x, target_y)
                                        already_clicked_y.append(center_y)
                                        time.sleep(1.5)
                                
                                # 20% 概率进入详情
                                elif action_roll < 0.5:
                                    bot.log("📄 查看详情...")
                                    target_node.Click_events()
                                    
                                    stay_time = random.uniform(8, 15)
                                    time.sleep(stay_time)
                                    
                                    if random.random() < 0.6:
                                        bot.swipe_screen("up", distance=0.5)
                                        time.sleep(2)
                                    
                                    bot.rpa.pressBack()
                                    time.sleep(2)

                # 滑动
                bot.swipe_screen("up", distance=random.uniform(0.5, 0.8))
                time.sleep(random.uniform(4, 8))
            
            bot.log(f"✅ 关键词 {final_kw} 浏览完成")
            time.sleep(3)

        # 5. 回到主页并刷新
        bot.log("🏠 回到主页并刷新...")
        bot.shell_cmd(XScheme.wrap_command(XScheme.HOME))
        time.sleep(3)
        bot.swipe_screen("down", distance=0.6)
        time.sleep(3)
        
        bot.log("🎉 养号任务完成")

    except Exception as e:
        bot.log(f"❌ 异常: {e}")
        import traceback
        traceback.print_exc()
    finally:
        bot.quit()
