# tasks/task_soft_reset.py
import time
import random
import requests
from common.bot_agent import BotAgent
from common.box_api import BoxApi
from common.x_config import XConfig
from common.blogger_manager import BloggerManager # 引入管理器

def remove_account_via_ui(bot):
    """
    通过系统设置 UI 移除 X 账号
    """
    bot.log("⚙️ 打开系统账号设置...")
    bot.shell_cmd("am start -a android.settings.SYNC_SETTINGS")
    time.sleep(3)
    
    target_account = None
    selector = bot.rpa.create_selector()
    
    with selector:
        selector.addQuery_TextEqual("X")
        selector.addQuery_IdEqual("android:id/summary")
        node = selector.execQueryOne(2000)
        if node:
            target_account = node
        else:
            selector.clear_Query()
            selector.addQuery_TextEqual("Twitter")
            selector.addQuery_IdEqual("android:id/summary")
            node = selector.execQueryOne(2000)
            if node: target_account = node

    if target_account:
        bot.log("✅ 找到 X 账号，点击进入...")
        target_account.Click_events()
        time.sleep(2)
        
        remove_keywords = ["アカウントを削除", "削除", "Remove account", "Remove"]
        clicked_remove = False
        
        for kw in remove_keywords:
            if bot.click_text(kw):
                bot.log(f"点击移除: {kw}")
                clicked_remove = True
                time.sleep(1.5)
                break
        
        if clicked_remove:
            for kw in remove_keywords:
                if bot.click_text(kw):
                    bot.log(f"点击确认移除: {kw}")
                    time.sleep(2)
                    return True
            bot.log("⚠️ 未找到确认移除按钮")
        else:
            bot.log("⚠️ 未找到移除按钮")
    else:
        bot.log("ℹ️ 未在设置中发现 X 账号 (可能已清除)")
        return True

    return False

def run_soft_reset_task(device_info, account_data, stop_event):
    """
    软重置任务：UI移除账号 -> pm clear -> 换机型 -> 换IP -> 换指纹
    """
    host_ip = device_info['ip']
    idx = device_info['index']
    _, api_port = BotAgent.calculate_ports(idx)
    api_base_url = f"http://{host_ip}:{api_port}"
    
    box = BoxApi(host_ip)
    bot = BotAgent(idx, host_ip)

    print(f"[设备{idx}] 开始软重置流程...")

    try:
        # 0. 清除博主绑定 (新增)
        BloggerManager.reset_binding_and_cooling(idx)
        print(f"[设备{idx}] 已清除博主绑定和采集冷却")

        # 1. 获取当前云机信息
        devs = box.get_android_list(idx)
        if not devs:
            print(f"[设备{idx}] ❌ 无法获取云机信息")
            return
        
        current_dev = devs[0]
        dev_name = current_dev['name']
        print(f"[设备{idx}] 目标云机: {dev_name}")

        # 2. 清除数据 (UI移除 + pm clear)
        if bot.connect():
            print(f"[设备{idx}] 正在执行深度清除...")
            remove_account_via_ui(bot)
            
            bot.shell_cmd(f"am force-stop {XConfig.PACKAGE_NAME}")
            ret, output = bot.shell_cmd(f"pm clear {XConfig.PACKAGE_NAME}")
            if "Success" in str(output):
                print(f"[设备{idx}] ✅ pm clear 成功")
            
            bot.shell_cmd(f"rm -rf /sdcard/Android/data/{XConfig.PACKAGE_NAME}")
            bot.shell_cmd("rm -rf /sdcard/Twitter")
            bot.shell_cmd("rm -rf /sdcard/.Twitter")
            
            bot.quit()
        else:
            print(f"[设备{idx}] ⚠️ ADB连接失败，跳过清除数据步骤")

        # 3. 切换机型
        models = box.get_phone_models()
        if models:
            target_model = random.choice(models)
            model_id = target_model['id']
            model_name = target_model['name']
            
            print(f"[设备{idx}] 正在切换机型为: {model_name} (ID:{model_id})...")
            if box.switch_model(dev_name, model_id):
                print(f"[设备{idx}] 机型切换指令发送成功，等待重启 (约20s)...")
                time.sleep(20)
                
                for _ in range(20):
                    if stop_event.is_set(): return
                    d = box.get_android_list(idx)
                    if d and d[0]['status'] == 'running':
                        print(f"[设备{idx}] 设备已重新上线")
                        break
                    time.sleep(2)
            else:
                print(f"[设备{idx}] ❌ 切换机型失败")
                return
        else:
            print(f"[设备{idx}] ❌ 获取机型列表失败")
            return

        # 4. 设置新环境
        time.sleep(5)
        
        # (1) 设置 S5 代理 (预留)
        proxy_info = None 
        if account_data and 'proxy' in account_data:
            proxy_info = account_data['proxy']
        
        if proxy_info:
            print(f"[设备{idx}] 正在设置 S5 代理...")
            try:
                parts = proxy_info.split(':')
                if len(parts) >= 4:
                    p_ip, p_port, p_user, p_pass = parts[0], parts[1], parts[2], parts[3]
                    proxy_url = f"{api_base_url}/proxy"
                    params = {
                        "cmd": 2,
                        "type": 2,
                        "ip": p_ip,
                        "port": p_port,
                        "usr": p_user,
                        "pwd": p_pass
                    }
                    requests.get(proxy_url, params=params, timeout=5)
                    print(f"[设备{idx}] ✅ S5 代理已设置")
            except Exception as e:
                print(f"[设备{idx}] ⚠️ 设置代理失败: {e}")
        else:
            print(f"[设备{idx}] (预留) 未配置 S5 代理，跳过")

        # (2) 重置谷歌 ID
        print(f"[设备{idx}] 重置 Google ID...")
        try:
            requests.get(f"{api_base_url}/adid?cmd=2", timeout=5)
        except:
            pass

        # (3) 刷新 IP 定位
        print(f"[设备{idx}] 刷新 IP 定位...")
        try:
            requests.get(f"{api_base_url}/modifydev?cmd=11", timeout=5)
            print(f"[设备{idx}] IP 刷新指令已发送，等待设备重新上线 (约60s)...")
            
            time.sleep(10)
            
            for i in range(30):
                if stop_event.is_set(): return
                d = box.get_android_list(idx)
                if d and d[0]['status'] == 'running':
                    if bot.connect():
                        print(f"[设备{idx}] ✅ 设备已重新上线且 ADB 可连接")
                        bot.quit()
                        break
                time.sleep(2)
                if i % 5 == 0:
                    print(f"[设备{idx}] 等待中... ({i*2}s)")
                    
        except Exception as e:
            print(f"[设备{idx}] ⚠️ 刷新 IP 异常: {e}")
            
        print(f"[设备{idx}] ✅ 软重置完成！")

    except Exception as e:
        print(f"[设备{idx}] ❌ 异常: {e}")
        import traceback
        traceback.print_exc()
