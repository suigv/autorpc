# main.py
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from tkinter.scrolledtext import ScrolledText
import threading
import time
import datetime
import queue
from common.bot_agent import BotAgent
from common.account_handler import AccountHandler
from common.x_config import XConfig
from tasks.task_login import run_login_task
from tasks.task_soft_reset import run_soft_reset_task
from tasks.task_clone_profile import run_clone_profile_task
from tasks.task_follow_followers import run_follow_followers_task
from tasks.task_reply_dm import run_reply_dm_task
from tasks.task_paypay_nurture import run_paypay_nurture_task
from tasks.task_reboot_device import reboot_device_via_api

# --- 🎨 暗黑风格配置 ---
THEME = {
    "bg_root": "#2B2B2B",       # 窗口背景
    "bg_panel": "#313335",      # 顶部面板背景
    "bg_card": "#3C3F41",       # 设备卡片背景
    "fg_text": "#A9B7C6",       # 普通文字
    "fg_title": "#CC7832",      # 标题文字 (橙色)
    "fg_info": "#6A8759",       # 信息文字 (绿色)
    "btn_start_bg": "#499C54",  # 开始按钮背景
    "btn_start_fg": "#FFFFFF",
    "btn_stop_bg": "#9E2927",   # 停止按钮背景
    "btn_stop_fg": "#FFFFFF",
    "entry_bg": "#45494A",      # 输入框背景
    "entry_fg": "#FFFFFF",
    "border": "#555555",        # 边框颜色
    "chk_bg": "#3C3F41",        # 复选框背景
    "chk_fg": "#A9B7C6",        # 复选框文字
    "chk_select": "#CC7832",    # 复选框选中颜色
    "log_bg": "#1E1E1E",        # 日志背景
    "log_fg": "#BBBBBB"         # 日志文字
}

TOTAL_DEVICES = 10  # 设备数量

# 全局日志队列
log_queue = queue.Queue()

def gui_log(message):
    """将日志放入队列"""
    timestamp = datetime.datetime.now().strftime("%H:%M:%S")
    log_queue.put(f"[{timestamp}] {message}")

class DeviceCard(tk.Frame):
    """
    单台设备控制卡片 (中控单元)
    """
    def __init__(self, parent, index, get_global_config):
        super().__init__(parent, bg=THEME["bg_card"], bd=1, relief="solid")
        self.index = index
        self.get_global_config = get_global_config
        self.stop_event = threading.Event()
        self.is_running = False

        # 端口计算
        self.rpa_port, self.api_port = BotAgent.calculate_ports(index)

        # 任务变量 (默认勾选后三项)
        self.var_reset = tk.BooleanVar(value=False)
        self.var_login = tk.BooleanVar(value=False)
        self.var_clone = tk.BooleanVar(value=False)
        self.var_follow = tk.BooleanVar(value=True) # 默认勾选
        self.var_dm = tk.BooleanVar(value=True)     # 默认勾选
        self.var_paypay = tk.BooleanVar(value=True) # 默认勾选

        self._init_ui()

    def _init_ui(self):
        # 1. 标题栏
        header = tk.Frame(self, bg=THEME["bg_card"])
        header.pack(fill="x", padx=5, pady=5)
        
        tk.Label(header, text=f"DEVICE #{self.index:02d}", 
                 bg=THEME["bg_card"], fg=THEME["fg_title"], 
                 font=("Consolas", 12, "bold")).pack(side="left")
        
        tk.Label(header, text=f"R:{self.rpa_port}", 
                 bg=THEME["bg_card"], fg="#808080", font=("Arial", 9)).pack(side="right")

        # 2. 状态显示区
        self.status_frame = tk.Frame(self, bg=THEME["bg_card"], height=28)
        self.status_frame.pack(fill="x", padx=5)
        self.status_frame.pack_propagate(False)
        
        self.lbl_status = tk.Label(self.status_frame, text="[ IDLE ]", 
                                   bg=THEME["bg_card"], fg=THEME["fg_text"], font=("Arial", 10))
        self.lbl_status.pack(expand=True)

        # 3. 任务选项区 (使用 grid 布局)
        opt_frame = tk.Frame(self, bg=THEME["bg_card"])
        opt_frame.pack(fill="x", padx=5, pady=5)
        
        chk_style = {"bg": THEME["bg_card"], "fg": THEME["chk_fg"], 
                     "selectcolor": THEME["bg_card"], "activebackground": THEME["bg_card"], 
                     "activeforeground": THEME["chk_select"], "font": ("Arial", 10)}

        tk.Checkbutton(opt_frame, text="一键新机", variable=self.var_reset, **chk_style).grid(row=0, column=0, sticky="w")
        tk.Checkbutton(opt_frame, text="自动登录", variable=self.var_login, **chk_style).grid(row=0, column=1, sticky="w")
        tk.Checkbutton(opt_frame, text="仿冒博主", variable=self.var_clone, **chk_style).grid(row=1, column=0, sticky="w")
        tk.Checkbutton(opt_frame, text="关注截流", variable=self.var_follow, **chk_style).grid(row=1, column=1, sticky="w")
        tk.Checkbutton(opt_frame, text="私信回复", variable=self.var_dm, **chk_style).grid(row=2, column=0, sticky="w")
        
        self.chk_paypay = tk.Checkbutton(opt_frame, text="PayPay养号", variable=self.var_paypay, **chk_style)
        self.chk_paypay.grid(row=2, column=1, sticky="w")

        # 4. 控制按钮区
        btn_frame = tk.Frame(self, bg=THEME["bg_card"])
        btn_frame.pack(fill="x", padx=5, pady=10, side="bottom")

        self.btn_start = tk.Button(btn_frame, text="启动", 
                                   bg=THEME["btn_start_bg"], fg=THEME["btn_start_fg"],
                                   activebackground="#5EA96A", activeforeground="white",
                                   relief="flat", width=6, font=("Arial", 10, "bold"),
                                   command=self.start_task)
        self.btn_start.pack(side="left", padx=5, expand=True, fill="x")

        self.btn_stop = tk.Button(btn_frame, text="停止", 
                                  bg=THEME["btn_stop_bg"], fg=THEME["btn_stop_fg"],
                                  activebackground="#B53B39", activeforeground="white",
                                  relief="flat", width=6, font=("Arial", 10, "bold"),
                                  command=self.stop_task, state="disabled")
        self.btn_stop.pack(side="right", padx=5, expand=True, fill="x")
        
        # 右键菜单
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="🔄 强制重启云机", command=self.force_reboot)
        self.bind("<Button-3>", self.show_context_menu)

    def show_context_menu(self, event):
        self.context_menu.post(event.x_root, event.y_root)

    def force_reboot(self):
        if messagebox.askyesno("确认", f"确定要强制重启设备 #{self.index} 吗？"):
            config = self.get_global_config()
            threading.Thread(target=reboot_device_via_api, 
                             args=(config["ip"], self.index, self.log_wrapper)).start()

    def update_status(self, text, color=None):
        if not color: color = THEME["fg_text"]
        self.lbl_status.config(text=text, fg=color)

    def log_wrapper(self, msg):
        full_msg = f"[Dev {self.index}] {msg}"
        print(full_msg)
        gui_log(full_msg)

    def start_task(self, override_opts=None):
        if self.is_running: return

        config = self.get_global_config()
        host_ip = config.get("ip")
        delay = config.get("delay", 0)
        ai_type = config.get("ai_type", "volc")

        if not host_ip:
            self.update_status("IP错误", "#FF0000")
            return

        do_reset = self.var_reset.get()
        do_login = self.var_login.get()
        do_clone = self.var_clone.get()
        do_follow = self.var_follow.get()
        do_dm = self.var_dm.get()
        do_paypay = self.var_paypay.get()
        
        if override_opts:
            do_reset = override_opts.get("reset", False)
            do_login = override_opts.get("login", False)
            do_clone = override_opts.get("clone", False)
            do_follow = override_opts.get("follow", False)
            do_dm = override_opts.get("dm", False)
            do_paypay = override_opts.get("paypay", False)
            
            self.var_reset.set(do_reset)
            self.var_login.set(do_login)
            self.var_clone.set(do_clone)
            self.var_follow.set(do_follow)
            self.var_dm.set(do_dm)
            self.var_paypay.set(do_paypay)

        if do_paypay and ai_type != "part_time":
            self.log_wrapper("⚠️ PayPay任务仅在兼职接口下可用，已自动跳过")
            do_paypay = False
            self.var_paypay.set(False)

        if not any([do_reset, do_login, do_clone, do_follow, do_dm, do_paypay]):
            self.update_status("未选任务", "#FFFF00")
            return

        self.stop_event.clear()
        self.is_running = True
        self.btn_start.config(state="disabled", bg="#555555")
        self.btn_stop.config(state="normal", bg=THEME["btn_stop_bg"])
        self.update_status("准备启动...", THEME["fg_info"])

        device_info = {
            "ip": host_ip,
            "index": self.index,
            "rpa_port": self.rpa_port,
            "api_port": self.api_port,
            "delay": delay,
            "ai_type": ai_type
        }

        thread = threading.Thread(
            target=self._run_wrapper,
            args=(device_info, do_reset, do_login, do_clone, do_follow, do_dm, do_paypay)
        )
        thread.daemon = True
        thread.start()

    def _run_wrapper(self, device_info, do_reset, do_login, do_clone, do_follow, do_dm, do_paypay):
        self.log_wrapper("任务线程启动")
        
        delay = device_info.get("delay", 0)
        if delay > 0:
            for i in range(delay, 0, -1):
                if self.stop_event.is_set(): return
                self.update_status(f"延迟: {i}s", "#FFFF00")
                time.sleep(1)
        
        try:
            # --- 1. 初始化阶段 (只执行一次) ---
            if do_reset:
                if self.stop_event.is_set(): return
                self.update_status("一键新机...", "#00FFFF")
                self.log_wrapper("开始一键新机")
                run_soft_reset_task(device_info, None, self.stop_event)
                if self.stop_event.is_set(): return
                time.sleep(2)

            if do_login:
                if self.stop_event.is_set(): return
                self.update_status("自动登录...", "#00FF00")
                self.log_wrapper("开始自动登录")
                run_login_task(device_info, None, self.stop_event)
                if self.stop_event.is_set(): return
                time.sleep(2)

            if do_clone:
                if self.stop_event.is_set(): return
                self.update_status("仿冒博主...", "#FF00FF")
                self.log_wrapper("开始仿冒博主")
                run_clone_profile_task(device_info, None, self.stop_event)
                if self.stop_event.is_set(): return
                time.sleep(2)

            # --- 2. 循环阶段 (反复执行) ---
            if not any([do_follow, do_dm, do_paypay]):
                self.log_wrapper("无循环任务，流程结束")
                return

            while not self.stop_event.is_set():
                # 检查连接
                bot = BotAgent(self.index, device_info['ip'])
                if not bot.connect():
                    self.log_wrapper("⚠️ 连接失败，尝试自动重启恢复...")
                    self.update_status("自动恢复中...", "#FFA500")
                    if reboot_device_via_api(device_info['ip'], self.index, self.log_wrapper):
                        self.log_wrapper("✅ 恢复成功，继续任务")
                    else:
                        raise ConnectionError("设备无法连接且恢复失败")

                # --- 封禁/掉线检测 ---
                if not bot.is_on_home_page():
                    # 检查是否在登录页
                    login_keywords = [XConfig.UI_TEXT.get("LOGIN_BTN_1", "ログイン"), "Log in", "Sign up"]
                    if bot.is_on_page(login_keywords):
                        self.log_wrapper("🚫 检测到账号掉线/封禁，触发重置流程...")
                        self.update_status("账号异常重置...", "#FF0000")
                        
                        run_soft_reset_task(device_info, None, self.stop_event)
                        if self.stop_event.is_set(): break
                        
                        run_login_task(device_info, None, self.stop_event)
                        if self.stop_event.is_set(): break
                        
                        run_clone_profile_task(device_info, None, self.stop_event)
                        if self.stop_event.is_set(): break
                        
                        self.log_wrapper("✅ 重置流程完成，恢复循环任务")
                        continue

                if do_follow:
                    if self.stop_event.is_set(): break
                    self.update_status("关注截流...", "#FFA500")
                    self.log_wrapper("开始关注截流")
                    run_follow_followers_task(device_info, None, self.stop_event)
                    if self.stop_event.is_set(): break
                    time.sleep(2)

                if do_dm:
                    if self.stop_event.is_set(): break
                    self.update_status("私信回复...", "#FF69B4")
                    self.log_wrapper("开始私信回复")
                    run_reply_dm_task(device_info, None, self.stop_event)
                    if self.stop_event.is_set(): break
                    time.sleep(2)
                    
                if do_paypay:
                    if self.stop_event.is_set(): break
                    self.update_status("PayPay养号...", "#FFD700")
                    self.log_wrapper("开始PayPay养号")
                    run_paypay_nurture_task(device_info, None, self.stop_event)

                self.update_status("本轮完成", THEME["fg_text"])
                self.log_wrapper("本轮任务结束，等待 15s 后继续...")
                
                # 等待 15s
                for i in range(15, 0, -1):
                    if self.stop_event.is_set(): break
                    self.update_status(f"冷却: {i}s", "#808080")
                    time.sleep(1)

        except Exception as e:
            self.log_wrapper(f"异常: {e}")
            self.update_status("异常", "#FF0000")
        finally:
            self.is_running = False
            try:
                self.btn_start.config(state="normal", bg=THEME["btn_start_bg"])
                self.btn_stop.config(state="disabled", bg="#555555")
                if not self.stop_event.is_set():
                    self.update_status("[ IDLE ]", THEME["fg_text"])
                else:
                    self.update_status("已停止", "#FF5555")
            except:
                pass

    def stop_task(self):
        self.stop_event.set()
        self.update_status("停止中...", "#FF5555")
        self.log_wrapper("收到停止指令")


class MytControllerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Myt X 自动化总控台 [Dark Edition]")
        self.root.geometry("1280x800")
        self.root.configure(bg=THEME["bg_root"])
        
        self.devices = []
        
        # 全局任务变量
        self.g_var_reset = tk.BooleanVar(value=False)
        self.g_var_login = tk.BooleanVar(value=False)
        self.g_var_clone = tk.BooleanVar(value=False)
        self.g_var_follow = tk.BooleanVar(value=True)
        self.g_var_dm = tk.BooleanVar(value=True)
        self.g_var_paypay = tk.BooleanVar(value=True)
        self.g_var_schedule = tk.BooleanVar(value=False)
        
        self._init_master_control()
        self._init_device_grid()
        self._init_log_area()
        
        self.root.after(100, self._update_log)
        self.root.after(60000, self._schedule_monitor)

    def _init_master_control(self):
        panel = tk.Frame(self.root, bg=THEME["bg_panel"], bd=1, relief="raised")
        panel.pack(fill="x", side="top")

        tk.Label(panel, text="Myt X Master", bg=THEME["bg_panel"], fg=THEME["fg_title"], 
                 font=("Impact", 18)).pack(side="left", padx=20, pady=15)

        conf_frame = tk.Frame(panel, bg=THEME["bg_panel"])
        conf_frame.pack(side="left", padx=20)

        tk.Label(conf_frame, text="IP:", bg=THEME["bg_panel"], fg=THEME["fg_text"], font=("Arial", 10)).pack(side="left", padx=2)
        self.entry_ip = tk.Entry(conf_frame, bg=THEME["entry_bg"], fg=THEME["entry_fg"], 
                                 insertbackground="white", width=14, font=("Arial", 10))
        self.entry_ip.insert(0, "192.168.1.215")
        self.entry_ip.pack(side="left", padx=5)

        tk.Label(conf_frame, text="Delay:", bg=THEME["bg_panel"], fg=THEME["fg_text"], font=("Arial", 10)).pack(side="left", padx=2)
        self.entry_delay = tk.Entry(conf_frame, bg=THEME["entry_bg"], fg=THEME["entry_fg"], 
                                    insertbackground="white", width=4, font=("Arial", 10))
        self.entry_delay.insert(0, "5")
        self.entry_delay.pack(side="left", padx=5)
        
        tk.Label(conf_frame, text="AI:", bg=THEME["bg_panel"], fg=THEME["fg_text"], font=("Arial", 10)).pack(side="left", padx=2)
        self.combo_ai = ttk.Combobox(conf_frame, values=["交友接口", "兼职接口"], state="readonly", width=8, font=("Arial", 10))
        self.combo_ai.current(0)
        self.combo_ai.pack(side="left", padx=5)
        
        self.combo_ai.bind("<<ComboboxSelected>>", self.on_ai_change)

        # 全局任务
        opt_frame = tk.Frame(panel, bg=THEME["bg_panel"])
        opt_frame.pack(side="left", padx=20)
        
        chk_style = {"bg": THEME["bg_panel"], "fg": THEME["fg_text"], 
                     "selectcolor": THEME["bg_panel"], "activebackground": THEME["bg_panel"], 
                     "activeforeground": THEME["chk_select"], "font": ("Arial", 10)}
        
        tk.Checkbutton(opt_frame, text="一键新机", variable=self.g_var_reset, **chk_style).grid(row=0, column=0)
        tk.Checkbutton(opt_frame, text="自动登录", variable=self.g_var_login, **chk_style).grid(row=0, column=1)
        tk.Checkbutton(opt_frame, text="仿冒博主", variable=self.g_var_clone, **chk_style).grid(row=0, column=2)
        tk.Checkbutton(opt_frame, text="关注截流", variable=self.g_var_follow, **chk_style).grid(row=1, column=0)
        tk.Checkbutton(opt_frame, text="私信回复", variable=self.g_var_dm, **chk_style).grid(row=1, column=1)
        
        self.chk_paypay_g = tk.Checkbutton(opt_frame, text="PayPay养号", variable=self.g_var_paypay, **chk_style)
        self.chk_paypay_g.grid(row=1, column=2)
        
        # 定时执行开关
        tk.Checkbutton(opt_frame, text="定时托管 (10:00-19:00)", variable=self.g_var_schedule, **chk_style).grid(row=2, column=0, columnspan=3)
        
        # 修复：先创建完所有控件，再调用初始化
        self.on_ai_change(None)

        # 按钮
        btn_frame = tk.Frame(panel, bg=THEME["bg_panel"])
        btn_frame.pack(side="right", padx=20)

        tk.Button(btn_frame, text="🚀 启动", bg=THEME["btn_start_bg"], fg="white",
                  font=("Arial", 11, "bold"), relief="flat", padx=10,
                  command=self.start_all).pack(side="left", padx=5)

        tk.Button(btn_frame, text="🛑 停止", bg=THEME["btn_stop_bg"], fg="white",
                  font=("Arial", 11, "bold"), relief="flat", padx=10,
                  command=self.stop_all).pack(side="left", padx=5)

    def on_ai_change(self, event):
        selected = self.combo_ai.get()
        is_part_time = (selected == "兼职接口")
        
        if is_part_time:
            self.chk_paypay_g.config(state="normal")
            self.g_var_paypay.set(True)
        else:
            self.chk_paypay_g.config(state="disabled")
            self.g_var_paypay.set(False)
            
        for dev in self.devices:
            if is_part_time:
                dev.chk_paypay.config(state="normal")
                dev.var_paypay.set(True)
            else:
                dev.chk_paypay.config(state="disabled")
                dev.var_paypay.set(False)

    def _init_device_grid(self):
        self.main_split = tk.PanedWindow(self.root, orient="vertical", bg=THEME["bg_root"], sashwidth=4)
        self.main_split.pack(fill="both", expand=True, padx=10, pady=10)
        
        self.grid_container = tk.Frame(self.main_split, bg=THEME["bg_root"])
        self.main_split.add(self.grid_container, height=450)

        columns = 5
        for i in range(1, TOTAL_DEVICES + 1):
            card = DeviceCard(self.grid_container, i, self.get_config)
            row = (i - 1) // columns
            col = (i - 1) % columns
            card.grid(row=row, column=col, padx=5, pady=5, sticky="nsew")
            self.grid_container.grid_columnconfigure(col, weight=1)
            self.devices.append(card)

    def _init_log_area(self):
        log_frame = tk.Frame(self.main_split, bg=THEME["bg_root"])
        self.main_split.add(log_frame)
        
        lbl_log = tk.Label(log_frame, text="运行日志", bg=THEME["bg_root"], fg=THEME["fg_info"], anchor="w", font=("Arial", 10))
        lbl_log.pack(fill="x")
        
        self.log_text = ScrolledText(log_frame, bg=THEME["log_bg"], fg=THEME["log_fg"], 
                                     font=("Consolas", 10), state="disabled", height=20)
        self.log_text.pack(fill="both", expand=True)

    def _update_log(self):
        while not log_queue.empty():
            try:
                msg = log_queue.get_nowait()
                self.log_text.config(state="normal")
                self.log_text.insert("end", msg + "\n")
                self.log_text.see("end")
                self.log_text.config(state="disabled")
            except queue.Empty:
                break
        self.root.after(100, self._update_log)
        
    def _schedule_monitor(self):
        """定时任务监控 (每分钟执行一次)"""
        if self.g_var_schedule.get():
            now = datetime.datetime.now()
            hour = now.hour
            
            any_running = any(dev.is_running for dev in self.devices)
            
            # 自动停止 (19:00 - 09:59)
            if hour >= 19 or hour < 10:
                if any_running:
                    gui_log(f"⏰ 定时任务: 当前时间 {now.strftime('%H:%M')}，停止所有任务")
                    self.stop_all()
            
            # 自动开始 (10:00 - 18:59)
            elif 10 <= hour < 19:
                if not any_running:
                    gui_log(f"⏰ 定时任务: 当前时间 {now.strftime('%H:%M')}，启动所有任务")
                    self.start_all()
                    
        self.root.after(60000, self._schedule_monitor)

    def get_config(self):
        ai_map = {"交友接口": "volc", "兼职接口": "part_time"}
        return {
            "ip": self.entry_ip.get().strip(),
            "delay": int(self.entry_delay.get().strip() or 0),
            "ai_type": ai_map.get(self.combo_ai.get(), "volc")
        }

    def start_all(self):
        g_opts = [self.g_var_reset.get(), self.g_var_login.get(), 
                  self.g_var_clone.get(), self.g_var_follow.get(), 
                  self.g_var_dm.get(), self.g_var_paypay.get()]
        
        if not any(g_opts):
            gui_log("⚠️ 启动失败: 未勾选任何任务")
            return

        opts = {
            "reset": g_opts[0], "login": g_opts[1], "clone": g_opts[2], 
            "follow": g_opts[3], "dm": g_opts[4], "paypay": g_opts[5]
        }

        def _batch_start():
            for device in self.devices:
                if not device.is_running:
                    device.start_task(override_opts=opts)
                    time.sleep(0.5)
        
        threading.Thread(target=_batch_start, daemon=True).start()

    def stop_all(self):
        for device in self.devices:
            if device.is_running:
                device.stop_task()

if __name__ == "__main__":
    root = tk.Tk()
    app = MytControllerApp(root)
    root.mainloop()